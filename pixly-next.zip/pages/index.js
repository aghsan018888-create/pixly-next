import PixlyHome from '../components/PixlyHome'

export default function Home() {
  return <PixlyHome />
}